export class Answer {
    public quesId:number;
   public answer:string;
}
