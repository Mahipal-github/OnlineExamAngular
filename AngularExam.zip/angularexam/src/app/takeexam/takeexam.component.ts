import { Component, OnInit } from '@angular/core';
import { Answer } from '../answer';
import { ExamService } from '../exam.service';
import { ActivatedRoute } from '@angular/router';
import { Question } from '../question';

@Component({
  selector: 'app-takeexam',
  templateUrl: './takeexam.component.html',
  styleUrls: ['./takeexam.component.css']
})
export class TakeexamComponent implements OnInit {
  questions:Question [] = [];
  answers:Answer[] =[]; 
  msg:string;
  msgFlag=false;
  examId:string;

  constructor(private examService:ExamService,private route:ActivatedRoute) { 
    console.log("take exam component");
  }

  ngOnInit(){
    console.log("oninit");
    
    this.route.paramMap.subscribe(params=>{this.examId= params.get('eid');
    console.log("exam Id", this.examId);
    
    this.examService.getQuestions(this.examId).subscribe(data=>{console.log(data);this.questions=data; 
    for(let idx in this.questions){this.answers.push(new Answer())}},
    error=>console.log(error));    
  });
    
  }
  addAnswer(idx:number, answer:string){
    console.log(idx);
    if(answer != undefined && answer != null)
    this.answers[idx].answer = answer;
    else
    this.answers[idx].answer = '';
    this.answers[idx].quesId= this.questions[idx].questionId;
  }

  submitTest(){
    console.log(this.answers);
    this.examService.submitTest(this.answers, '2001',this.examId).subscribe(data=>{this.msgFlag=true;this.msg=data.message});
  }

}
