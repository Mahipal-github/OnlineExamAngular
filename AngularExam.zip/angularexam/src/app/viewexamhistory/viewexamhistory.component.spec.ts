import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewexamhistoryComponent } from './viewexamhistory.component';

describe('ViewexamhistoryComponent', () => {
  let component: ViewexamhistoryComponent;
  let fixture: ComponentFixture<ViewexamhistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewexamhistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewexamhistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
