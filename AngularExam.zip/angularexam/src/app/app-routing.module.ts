import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { AssignexamComponent } from './assignexam/assignexam.component';
import { UploadComponent } from './upload/upload.component';
import { CgGuardService } from './cg-guard.service';
import { AdduserComponent } from './adduser/adduser.component';
import { AddexamComponent } from './addexam/addexam.component';
import { ViewexamhistoryComponent } from './viewexamhistory/viewexamhistory.component';
import { ViewexamtotakeComponent } from './viewexamtotake/viewexamtotake.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { TakeexamComponent } from './takeexam/takeexam.component';


const routes: Routes = [
  {path:'addquestion',component:AddquestionComponent},
  {path:'assignexam',component:AssignexamComponent},
  {path:'uploadques', component:UploadComponent},
 {path:'adduser',component:AdduserComponent},
 {path:'addexam',component:AddexamComponent},
  {path:'viewexamhistory',component:ViewexamhistoryComponent ,canActivate:[CgGuardService]},
  {path:'viewexamtotake',component:ViewexamtotakeComponent ,canActivate:[CgGuardService]},
  {path:'viewexamhistory',component:ViewexamhistoryComponent ,canActivate:[CgGuardService],data:{role:"admin"}},
  {path:'viewexamtotake',component:ViewexamtotakeComponent ,canActivate:[CgGuardService],data:{role:"user"}},
  {path:'error',component:ErrorPageComponent},
  {path:'takeexam/:eid',component:TakeexamComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
