import { Exam } from './exam';

export class Question {
    public questionId:number;
    public questionTitle:string;
    public optA:string;
    public optB:string;
    public optC:string;
    public optD:string;
    public answer:string;    
    public exam:Exam=new Exam();

}

    