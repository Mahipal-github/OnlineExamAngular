import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from './login';
import { ExamService } from './exam.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = "Welcome to Online Exam Management System";
  
  msg:string;
  errorMsg:string;
  login:Login=new Login();
  token:string=localStorage.getItem("token");
  
  tokenflag:boolean=false;
  // user:User=new User();
  constructor(private examSer:ExamService,private router:Router){

  }
  showLogin(){
    this.tokenflag=true;
   }
 
     hidelogin(){
     this.tokenflag=false;
   }

   download(){
    this.examSer.download().subscribe(data=>{let blob = new Blob([data],{type:'application/pdf'});

    var downloadURL = window.URL.createObjectURL(data);
    var link = document.createElement('a');
    link.href = downloadURL;
    link.download = "report.pdf";
    link.click();}
    );
   }
 
   doLogin(){
   this.examSer.doLogin(this.login.uname,this.login.pwd).subscribe(data=>{localStorage.setItem("token",data)
   let arr = data.split("-");
   this.tokenflag=false;
   this.token = localStorage.getItem("token");
  //  this.user.userName=this.examSer.decrypt(arr[1]);
 },
 error=>{console.log(error);this.errorMsg=error.error.message});

}

 
 logout():void{
   this.examSer.doLogout().subscribe(data=>{console.log(data);
   localStorage.removeItem("token");
   alert("you have logged out");
   this.tokenflag=true;
   this.token=undefined;
     
  });

  
  
   }
 
}
