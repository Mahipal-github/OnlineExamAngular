export class Exam {
    
    public examId:number;
    public examName:string;
    public minutes:number;
    

}
