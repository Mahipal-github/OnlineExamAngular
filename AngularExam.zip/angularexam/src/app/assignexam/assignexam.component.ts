import { Component, OnInit, ViewChild } from '@angular/core';
import { ExamService } from '../exam.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-assignexam',
  templateUrl: './assignexam.component.html',
  styleUrls: ['./assignexam.component.css']
})
export class AssignexamComponent implements OnInit {

@ViewChild("frm")
form:NgForm;
userId:number;
examId:number;
users:any=[]
exams:any=[];
errorMsg: string;
msg: string;

  constructor(private examService:ExamService) { }

  ngOnInit():void{
    this.examService.viewExams().subscribe(data=>this.exams=data);
    this.examService.viewUsers().subscribe(data=>this.users=data);

  }
 assignExamToUser(){
    this.examService.assignExam(this.examId, this.userId).subscribe(
     data=>{this.msg= data.message; this.form.resetForm()},
     error=> this.errorMsg= error.error.message);
    }
}