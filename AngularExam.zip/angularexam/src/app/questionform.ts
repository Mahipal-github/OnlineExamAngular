export class Questionform {

    public questionId:number;
    public questionTitle:string;
    public optA:string;
    public optB:string;
    public optC:string;
    public optD:string;
    public answer:string;    
    public examId:number;
}
