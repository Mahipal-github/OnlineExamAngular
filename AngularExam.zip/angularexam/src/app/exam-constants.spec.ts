import { ExamConstants } from './exam-constants';

describe('ExamConstants', () => {
  it('should create an instance', () => {
    expect(new ExamConstants()).toBeTruthy();
  });
});
