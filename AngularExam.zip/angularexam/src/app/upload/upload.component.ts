import { Component, OnInit } from '@angular/core';
import { ExamService } from '../exam.service';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

  qfile:File;
  msg:string;
  errorMsg: string;



  constructor(private examService:ExamService) { }

  ngOnInit(): void {
  }
  onFileChanged(event: any) {
   
    this.qfile= event.target.files[0];
  }
  
  uploadQuestions(){
    this.examService.uploadQuestions(this.qfile).subscribe(data=>{this.msg=data;console.log(data);});
}

}
