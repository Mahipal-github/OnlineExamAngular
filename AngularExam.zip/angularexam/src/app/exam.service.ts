import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Question } from './question';
import { Observable } from 'rxjs';
import { ExamConstants } from './exam-constants';
import { Questionform } from './questionform';
import { Exam } from './exam';
import { User } from './user';
import { Answer } from './answer';

@Injectable({
  providedIn: 'root'
})
export class ExamService {
 

  constructor(private http:HttpClient) { }
  
  public addQuestion(ques:Questionform):Observable<any>{
    return this.http.post(ExamConstants.ADD_QUES_URL, ques);
}

public assignExam(examId, userId):Observable<any>{
  return this.http.get(ExamConstants.ASSIGN_EXAM_URL+"/"+examId+ "/"+userId);
}

public uploadQuestions(qfile:File):Observable<any>{
  let postData = new FormData();
  postData.append('qfile' , qfile); 
  return this.http.post("http://localhost:8082/onlineexam/upload",postData, {responseType:'text'});
}

public addUser(user:User):Observable<any>{
  return this.http.post(ExamConstants.ADD_USER_URL, user);
}
public addExam(exam:Exam):Observable<any>{
  return this.http.post(ExamConstants.ADD_EXAM_URL, exam);
}
public viewExams():Observable<any>{
  return this.http.get(ExamConstants.VIEW_EXAMS_URL);
}
public viewUsers():Observable<any>{
  return this.http.get(ExamConstants.VIEW_USERS_URL);
}
public viewbyID(uid:number):Observable<any>{
  return this.http.get(ExamConstants.VIEW_USER_BYID+uid);
}
public viewExamHistory(userId:number):Observable<any>{
  return this.http.get(ExamConstants.VIEW_HISTORY_URL + userId);
  
}

public viewExamToTake(userId:number):Observable<any>{
  return this.http.get(ExamConstants.TAKE_EXAM_URL + userId)
}


public download():Observable<any>{
    return this.http.get("http://localhost:8082/onlineexam/viewpdf",{responseType:'blob' as 'json'});
}
decrypt(token:string){
  let str = "";
  for(let i=0; i<token.length; i++){
    str = str + String.fromCharCode(token.charCodeAt(i)-3);
  }
  console.log(str);
  return str;
}
public doLogin(userId: string, pwd: string):Observable<any> {
  let postData = new FormData();
  postData.append('userId',userId);
  postData.append('password',pwd);

  return  this.http.post("http://localhost:8082/onlineexam/login",postData,{responseType:'text'})
}

public doLogout(){
  let utoken = localStorage.getItem("token");
  if(utoken==null)utoken="";
  const httpHeaders = new HttpHeaders({"userId":utoken});
  return this.http.get("http://localhost:8082/onlineexam/logout",{headers:httpHeaders,responseType:'text'});
}
public getQuestions(examId:string):Observable<any>{
  return this.http.get("http://localhost:8082/onlineexam/viewQuestionsForExamId/"+examId);
}

public  submitTest(answers:Answer[], userId:string, examId:string):Observable<any>{
  return this.http.post("http://localhost:8082/onlineexam/submitanswers/"+examId + "/"+userId, answers);
}

}
