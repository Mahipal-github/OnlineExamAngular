import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddquestionComponent } from './addquestion/addquestion.component';
import { AssignexamComponent } from './assignexam/assignexam.component';
import { UploadComponent } from './upload/upload.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { AddexamComponent } from './addexam/addexam.component';
import { AdduserComponent } from './adduser/adduser.component';
import { ViewexamhistoryComponent } from './viewexamhistory/viewexamhistory.component';
import { ViewexamtotakeComponent } from './viewexamtotake/viewexamtotake.component';
import { TakeexamComponent } from './takeexam/takeexam.component';
import { ExamComponent } from './exam/exam.component';

@NgModule({
  declarations: [
    AppComponent,
    AddquestionComponent,
    AssignexamComponent,
    UploadComponent,
    ErrorPageComponent,
    AddexamComponent,
    AdduserComponent,
    ViewexamhistoryComponent,
    ViewexamtotakeComponent,
    TakeexamComponent,
    ExamComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
