import { Component, OnInit, ViewChild } from '@angular/core';
import { Question } from '../question';
import { Exam } from '../exam';
import { ExamService } from '../exam.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Questionform } from '../questionform';

@Component({
  selector: 'app-addquestion',
  templateUrl: './addquestion.component.html',
  styleUrls: ['./addquestion.component.css']
})
export class AddquestionComponent implements OnInit {
@ViewChild("frm")
private frm:NgForm;
ques:Questionform = new Questionform();
msg:string;
errorMsg:string;
exams:Exam[] = [];


  constructor(private examService:ExamService) { }

  ngOnInit(){
   this.examService.viewExams().subscribe(data=>this.exams= data);
  }

  addQuestion(){
    this.examService.addQuestion(this.ques).subscribe(data=>{this.msg = data.message;
                                                        this.frm.resetForm()   },
                                                        error=>this.errorMsg= error.error.message);
                                                                                                     
}


}
