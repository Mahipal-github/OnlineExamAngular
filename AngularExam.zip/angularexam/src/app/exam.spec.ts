import { Exam } from './exam';

describe('Exam', () => {
  it('should create an instance', () => {
    expect(new Exam()).toBeTruthy();
  });
});
