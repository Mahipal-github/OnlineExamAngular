import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewexamtotakeComponent } from './viewexamtotake.component';

describe('ViewexamtotakeComponent', () => {
  let component: ViewexamtotakeComponent;
  let fixture: ComponentFixture<ViewexamtotakeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewexamtotakeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewexamtotakeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
