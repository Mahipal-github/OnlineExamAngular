import { TestBed } from '@angular/core/testing';

import { CgGuardService } from './cg-guard.service';

describe('CgGuardService', () => {
  let service: CgGuardService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CgGuardService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
