export class ExamConstants {
    
    public  static ADD_QUES_URL = "http://localhost:8082/onlineexam/addQuestion/";
    public static VIEW_EXAMS_URL = "http://localhost:9082/examcontroller/viewexams";
    public static VIEW_USERS_URL = "http://localhost:9082/examcontroller/viewusers";
    public static ASSIGN_EXAM_URL = "http://localhost:8082/onlineexam/assignExam/";
    public static ADD_USER_URL = "http://localhost:9082/examcontroller/addUser/";   
    public static ADD_EXAM_URL = "http://localhost:9082/examcontroller/addExam/";
    public static VIEW_USER_BYID = "http://localhost:9082/examcontroller/viewuserbyid/"; 
    public static VIEW_HISTORY_URL = "http://localhost:8082/onlineexam/viewexamhistory/"
    public static TAKE_EXAM_URL = "http://localhost:8082/onlineexam/viewexamtotake/"
       

} 

