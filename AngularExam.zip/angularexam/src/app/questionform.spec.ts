import { Questionform } from './questionform';

describe('Questionform', () => {
  it('should create an instance', () => {
    expect(new Questionform()).toBeTruthy();
  });
});
