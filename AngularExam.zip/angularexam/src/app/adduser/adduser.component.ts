import { Component, OnInit, ViewChild } from '@angular/core';
import { ExamService } from '../exam.service';
import { NgForm } from '@angular/forms';
import { User } from '../user';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  @ViewChild("userfrm") 
  private userfrm:NgForm;
  msg:string;
  errorMsg:string;
  user:User = new User();
  users:User[] = [];
  userid:User=null;
  uid:number;
  showAddUserFlag:boolean=false;
  viewUserFlag:boolean=false;
  viewUserbyIdFlag:boolean=false;

  constructor(private examService:ExamService) { }

  ngOnInit(): void {
  }
  addUser(){
    this.examService.addUser(this.user).subscribe(data=>{this.msg = data.message;
      this.userfrm.resetForm()   },
    error=>this.errorMsg= error.error.message);
  }
  
  showAddUser(){
         this.showAddUserFlag=true;
         this.viewUserFlag=false;
         this.viewUserbyIdFlag=false;
  }
  
  viewUser(){
    this.examService.viewUsers().subscribe(data=>{this.users=data;
      this.showAddUserFlag =false;
      this.viewUserbyIdFlag=false; 
      this.viewUserFlag=true;});  
  }
  
  viewUserById(){
    this.examService.viewbyID(this.uid).subscribe(data=>{this.userid=data;},
      error=>this.errorMsg= error.error.message);
    }
    showViewUserById(){
      this.showAddUserFlag=false;
      this.viewUserFlag=false;
      this.viewUserbyIdFlag=true;
                  
  
  }

}
