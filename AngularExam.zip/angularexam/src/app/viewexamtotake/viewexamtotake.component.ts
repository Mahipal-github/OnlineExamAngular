import { Component, OnInit } from '@angular/core';
import { ExamService } from '../exam.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-viewexamtotake',
  templateUrl: './viewexamtotake.component.html',
  styleUrls: ['./viewexamtotake.component.css']
})
export class ViewexamtotakeComponent implements OnInit {

  userId:number ;
  exam: any;
  errorMsg: any;
  constructor(private examService:ExamService) { }

  ngOnInit(){
    let token = localStorage.getItem("token");
  let arr = token.split("-");
  this.userId=parseInt(this.examService.decrypt(arr[0]));
  exams:analyzeAndValidateNgModules;

  this.examService.viewExamToTake(this.userId).subscribe(data=>{console.log(data);this.exam=data},
                                                          error=>this.errorMsg=error.error.message)
  }

}
