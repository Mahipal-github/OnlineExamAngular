import { Component, OnInit } from '@angular/core';
import { ExamService } from '../exam.service';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-viewexamhistory',
  templateUrl: './viewexamhistory.component.html',
  styleUrls: ['./viewexamhistory.component.css']
})
export class ViewexamhistoryComponent implements OnInit {
  userId:number ;
  history: any;
  errorMsg: any;

  constructor(private examService:ExamService) { }

  ngOnInit() {
    let token = localStorage.getItem("token");
    let arr = token.split("-");
    this.userId=parseInt(this.examService.decrypt(arr[0]));
    history:analyzeAndValidateNgModules;
    this.examService.viewExamHistory(this.userId).subscribe(data=>{console.log(data);this.history=data},
                                                            error=>this.errorMsg=error.error.message)
  }

}
