import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../user';
import { NgForm } from '@angular/forms';
import { Exam } from '../exam';
import { ExamService } from '../exam.service';

@Component({
  selector: 'app-addexam',
  templateUrl: './addexam.component.html',
  styleUrls: ['./addexam.component.css']
})
export class AddexamComponent implements OnInit {
  @ViewChild("examfrm")
private examfrm:NgForm;
msg:string;
errorMsg:string;
user:User = new User();
exam:Exam = new Exam();
exams:Exam[] = [];
addExamFlag:boolean=false;
viewExamFlag:Boolean=false;


  constructor(private examService:ExamService) { }

  ngOnInit(): void {
  }
  addExam(){
    this.examService.addExam(this.exam).subscribe(data=>{this.msg = data.message;
      this.examfrm.resetForm()   },
    error=>this.errorMsg= error.error.message);
  
  }
  
  showAddExam(){ 
    this.addExamFlag =true; 
    this.viewExamFlag=false;}
  
  showViewExam(){
  this.examService.viewExams().subscribe(data=>{this.exams=data;
     this.addExamFlag =false; 
     this.viewExamFlag=true;});
  }

}
